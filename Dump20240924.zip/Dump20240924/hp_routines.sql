-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: hp
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `consultas_do_dia`
--

DROP TABLE IF EXISTS `consultas_do_dia`;
/*!50001 DROP VIEW IF EXISTS `consultas_do_dia`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `consultas_do_dia` AS SELECT 
 1 AS `id_consulta`,
 1 AS `nome_paciente`,
 1 AS `agendamento`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `medicos_disponiveis`
--

DROP TABLE IF EXISTS `medicos_disponiveis`;
/*!50001 DROP VIEW IF EXISTS `medicos_disponiveis`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `medicos_disponiveis` AS SELECT 
 1 AS `id_consulta`,
 1 AS `nome_medico`,
 1 AS `agendamento`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pacientes_especialidade`
--

DROP TABLE IF EXISTS `pacientes_especialidade`;
/*!50001 DROP VIEW IF EXISTS `pacientes_especialidade`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `pacientes_especialidade` AS SELECT 
 1 AS `nome_especialidades`,
 1 AS `nome_paciente`,
 1 AS `dia_hora`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `faturamento_por_consulta`
--

DROP TABLE IF EXISTS `faturamento_por_consulta`;
/*!50001 DROP VIEW IF EXISTS `faturamento_por_consulta`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `faturamento_por_consulta` AS SELECT 
 1 AS `id_consulta`,
 1 AS `nome_paciente`,
 1 AS `nome_medico`,
 1 AS `nome_procedimento`,
 1 AS `preço`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `detalhes_consultas`
--

DROP TABLE IF EXISTS `detalhes_consultas`;
/*!50001 DROP VIEW IF EXISTS `detalhes_consultas`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `detalhes_consultas` AS SELECT 
 1 AS `nome_paciente`,
 1 AS `nome_medico`,
 1 AS `id_sala_consulta`,
 1 AS `consulta`,
 1 AS `dia_hora`,
 1 AS `procedimentos_realizados`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `consultas_do_dia`
--

/*!50001 DROP VIEW IF EXISTS `consultas_do_dia`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `consultas_do_dia` AS select `c`.`id_consulta` AS `id_consulta`,`p`.`nome` AS `nome_paciente`,`c`.`agendamento` AS `agendamento` from (`consulta` `c` join `paciente` `p` on((`c`.`id_paciente` = `p`.`id_paciente`))) order by `c`.`id_consulta`,`p`.`nome`,`c`.`agendamento` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `medicos_disponiveis`
--

/*!50001 DROP VIEW IF EXISTS `medicos_disponiveis`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `medicos_disponiveis` AS select `c`.`id_consulta` AS `id_consulta`,`m`.`nome` AS `nome_medico`,`c`.`agendamento` AS `agendamento` from (`consulta` `c` join `medico` `m` on((`c`.`id_medico` = `m`.`id_medico`))) order by `m`.`nome`,`c`.`agendamento` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pacientes_especialidade`
--

/*!50001 DROP VIEW IF EXISTS `pacientes_especialidade`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pacientes_especialidade` AS select `e`.`nome_especialidade` AS `nome_especialidades`,`p`.`nome` AS `nome_paciente`,`c`.`dia_hora` AS `dia_hora` from (((`consulta` `c` join `paciente` `p` on((`c`.`id_paciente` = `p`.`id_paciente`))) join `medico` `m` on((`c`.`id_medico` = `m`.`id_medico`))) join `especialidades` `e` on((`m`.`id_especialidades` = `e`.`id_especialidades`))) order by `e`.`nome_especialidade`,`p`.`nome` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `faturamento_por_consulta`
--

/*!50001 DROP VIEW IF EXISTS `faturamento_por_consulta`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `faturamento_por_consulta` AS select `c`.`id_consulta` AS `id_consulta`,`p`.`nome` AS `nome_paciente`,`m`.`nome` AS `nome_medico`,`proc`.`nome_procedimento` AS `nome_procedimento`,`proc`.`preço` AS `preço` from (((`consulta` `c` join `paciente` `p` on((`c`.`id_paciente` = `p`.`id_paciente`))) join `medico` `m` on((`c`.`id_medico` = `m`.`id_medico`))) left join `procedimento_medico` `proc` on((`c`.`id_procedimento_medico` = `proc`.`id_procedimento_medico`))) order by `c`.`id_consulta`,`proc`.`nome_procedimento`,`proc`.`preço` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `detalhes_consultas`
--

/*!50001 DROP VIEW IF EXISTS `detalhes_consultas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `detalhes_consultas` AS select `p`.`nome` AS `nome_paciente`,`m`.`nome` AS `nome_medico`,`s`.`id_sala_consulta` AS `id_sala_consulta`,`c`.`id_consulta` AS `consulta`,`c`.`dia_hora` AS `dia_hora`,group_concat(`proc`.`nome_procedimento` separator ', ') AS `procedimentos_realizados` from ((((`consulta` `c` join `paciente` `p` on((`c`.`id_paciente` = `p`.`id_paciente`))) join `medico` `m` on((`c`.`id_medico` = `m`.`id_medico`))) join `sala_consulta` `s` on((`c`.`id_sala_consulta` = `s`.`id_sala_consulta`))) left join `procedimento_medico` `proc` on((`c`.`id_procedimento_medico` = `proc`.`id_procedimento_medico`))) group by `c`.`id_consulta`,`p`.`nome`,`m`.`nome`,`s`.`id_sala_consulta`,`c`.`dia_hora` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping events for database 'hp'
--

--
-- Dumping routines for database 'hp'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-24 13:35:30
